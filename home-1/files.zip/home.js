/**
 * Solar-Echos | Home Page 1 — JavaScript
 * Author: TechEchos Innovation
 * Version: 1.0.0
 *
 * Modules:
 *  1. Solar Canvas Animation (Hero)
 *  2. ROI Calculator
 *  3. Testimonials Slider
 *  4. Counter Animation (Impact section)
 *  5. Post-component-injection Lucide refresh
 */

/* ============================================================
   1. SOLAR CANVAS ANIMATION
   Draws a real-time animated solar scene:
   – A glowing sun with pulsing corona
   – A house silhouette with solar panels on the roof
   – Energy particles flowing from panels → house
   – Animated grid lines representing the power network
   – Day/night sky with stars cycling
   ============================================================ */

(function initSolarCanvas() {

  const canvas  = document.getElementById('solar-canvas');
  if (!canvas) return;

  const ctx     = canvas.getContext('2d');
  let W, H, raf;
  let time      = 0;
  const particles = [];
  const MAX_PARTICLES = 55;

  /* ── Resize handler ── */
  function resize() {
    const dpr  = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    W = canvas.width  = rect.width  * dpr;
    H = canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    // logical dimensions
    W = rect.width;
    H = rect.height;
  }

  /* ── Get current theme ── */
  function isDark() {
    return document.documentElement.getAttribute('data-theme') === 'dark';
  }

  /* ── Color helpers ── */
  function lerp(a, b, t) { return a + (b - a) * t; }

  /* ── Particle class ── */
  class EnergyParticle {
    constructor() { this.reset(); }

    reset() {
      // Start from a random panel on the roof
      const panelCount = 5;
      const panelIdx   = Math.floor(Math.random() * panelCount);
      const panelW     = W * 0.055;
      const roofStartX = W * 0.28;
      const roofY      = H * 0.38;

      this.x    = roofStartX + panelIdx * (panelW + 4) + panelW * 0.5;
      this.y    = roofY;
      // Target: house centre / inverter
      this.tx   = W * 0.5 + (Math.random() - 0.5) * W * 0.15;
      this.ty   = H * 0.68 + Math.random() * H * 0.05;
      this.progress = 0;
      this.speed    = 0.005 + Math.random() * 0.008;
      this.size     = 2 + Math.random() * 2.5;
      this.alpha    = 0;
      this.color    = Math.random() > 0.5 ? '#FFD700' : '#4DBD33';
      this.trail    = [];
    }

    update() {
      this.progress = Math.min(1, this.progress + this.speed);
      const t  = this.progress;
      // Bezier curve path
      const cx = this.x + (this.tx - this.x) * 0.3;
      const cy = this.y - H * 0.25;
      const bx = Math.pow(1 - t, 2) * this.x + 2 * (1 - t) * t * cx + t * t * this.tx;
      const by = Math.pow(1 - t, 2) * this.y + 2 * (1 - t) * t * cy + t * t * this.ty;

      // Store trail
      this.trail.push({ x: bx, y: by });
      if (this.trail.length > 12) this.trail.shift();

      this.curX  = bx;
      this.curY  = by;
      this.alpha = t < 0.1 ? t * 10 : t > 0.85 ? (1 - t) * 6.67 : 1;

      if (this.progress >= 1) this.reset();
    }

    draw() {
      // Trail
      for (let i = 0; i < this.trail.length - 1; i++) {
        const ratio = i / this.trail.length;
        ctx.beginPath();
        ctx.moveTo(this.trail[i].x, this.trail[i].y);
        ctx.lineTo(this.trail[i + 1].x, this.trail[i + 1].y);
        ctx.strokeStyle = this.color + Math.round(ratio * this.alpha * 100).toString(16).padStart(2, '0');
        ctx.lineWidth   = this.size * ratio * 0.6;
        ctx.lineCap     = 'round';
        ctx.stroke();
      }
      // Particle dot
      ctx.beginPath();
      ctx.arc(this.curX, this.curY, this.size, 0, Math.PI * 2);
      const grad = ctx.createRadialGradient(this.curX, this.curY, 0, this.curX, this.curY, this.size * 2.5);
      grad.addColorStop(0, this.color);
      grad.addColorStop(1, this.color + '00');
      ctx.fillStyle = grad;
      ctx.globalAlpha = this.alpha;
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  /* Seed initial particles */
  for (let i = 0; i < MAX_PARTICLES; i++) {
    const p = new EnergyParticle();
    p.progress = Math.random(); // stagger
    particles.push(p);
  }

  /* ── Draw functions ── */

  /** Sky gradient */
  function drawSky() {
    const dark = isDark();
    const cycle = (Math.sin(time * 0.003) + 1) / 2; // 0=night, 1=noon
    const skyTop    = dark ? '#020d1a' : `hsl(${lerp(220, 200, cycle)}, ${lerp(60, 80, cycle)}%, ${lerp(10, 55, cycle)}%)`;
    const skyBottom = dark ? '#0a2040' : `hsl(${lerp(220, 30, cycle)}, ${lerp(40, 70, cycle)}%, ${lerp(20, 75, cycle)}%)`;

    const g = ctx.createLinearGradient(0, 0, 0, H * 0.75);
    g.addColorStop(0, skyTop);
    g.addColorStop(1, skyBottom);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H * 0.75);
  }

  /** Ground strip */
  function drawGround() {
    const dark = isDark();
    const g = ctx.createLinearGradient(0, H * 0.73, 0, H);
    g.addColorStop(0, dark ? '#0d1f0d' : '#a8d5a2');
    g.addColorStop(1, dark ? '#060d06' : '#5e9a58');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(W * 0.5, H * 0.78, W * 0.7, H * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  /** Stars (only at night / dark mode) */
  function drawStars() {
    const cycle = (Math.sin(time * 0.003) + 1) / 2;
    const opacity = isDark() ? 0.7 : Math.max(0, 1 - cycle * 2.5);
    if (opacity <= 0) return;
    ctx.fillStyle = `rgba(255,255,255,${opacity})`;
    // Use seeded pseudo-random for stable star positions
    const seed = 42;
    for (let i = 0; i < 60; i++) {
      const sx = ((seed * (i + 1) * 7919) % W);
      const sy = ((seed * (i + 1) * 2731) % (H * 0.55));
      const r  = 0.5 + (i % 3) * 0.4;
      const tw = (Math.sin(time * 0.05 + i) + 1) / 2;
      ctx.globalAlpha = opacity * (0.5 + tw * 0.5);
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  /** Sun with corona rings */
  function drawSun() {
    const dark  = isDark();
    const cycle = (Math.sin(time * 0.003) + 1) / 2;
    const sunX  = W * 0.78;
    const sunY  = H * (dark ? 0.12 : lerp(0.6, 0.15, cycle));
    const sunR  = W * 0.07;

    // Outer glow rings (pulsing)
    for (let r = 3; r >= 1; r--) {
      const ringR  = sunR * (1 + r * 0.45 + Math.sin(time * 0.04 + r) * 0.05);
      const alpha  = dark ? 0.04 : (0.06 + cycle * 0.06);
      ctx.beginPath();
      ctx.arc(sunX, sunY, ringR, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255, 215, 0, ${alpha})`;
      ctx.fill();
    }

    // Solar rays
    const rayCount = 12;
    for (let i = 0; i < rayCount; i++) {
      const angle    = (i / rayCount) * Math.PI * 2 + time * 0.005;
      const rayStart = sunR * 1.25;
      const rayEnd   = sunR * (1.6 + Math.sin(time * 0.06 + i) * 0.15);
      ctx.beginPath();
      ctx.moveTo(sunX + Math.cos(angle) * rayStart, sunY + Math.sin(angle) * rayStart);
      ctx.lineTo(sunX + Math.cos(angle) * rayEnd,   sunY + Math.sin(angle) * rayEnd);
      ctx.strokeStyle = dark ? 'rgba(255,215,0,0.25)' : `rgba(255,215,0,${0.4 + cycle * 0.3})`;
      ctx.lineWidth   = 2;
      ctx.lineCap     = 'round';
      ctx.stroke();
    }

    // Sun body
    const sunGrad = ctx.createRadialGradient(sunX - sunR * 0.2, sunY - sunR * 0.2, 0, sunX, sunY, sunR);
    sunGrad.addColorStop(0, '#fffde7');
    sunGrad.addColorStop(0.5, '#FFD700');
    sunGrad.addColorStop(1, '#f59e0b');
    ctx.beginPath();
    ctx.arc(sunX, sunY, sunR, 0, Math.PI * 2);
    ctx.fillStyle = sunGrad;
    ctx.shadowColor  = '#FFD700';
    ctx.shadowBlur   = dark ? 30 : 50;
    ctx.fill();
    ctx.shadowBlur   = 0;
  }

  /** House silhouette */
  function drawHouse() {
    const dark  = isDark();
    const baseX = W * 0.22;
    const baseY = H * 0.75;
    const hw    = W * 0.56;  // house width
    const hh    = H * 0.28;  // house height

    const wallColor = dark ? '#1a2a3a' : '#e8f0fe';
    const roofColor = dark ? '#0d1f33' : '#c5d9f2';

    // Main walls
    ctx.fillStyle = wallColor;
    ctx.beginPath();
    ctx.roundRect(baseX, baseY - hh, hw, hh, [0, 0, 8, 8]);
    ctx.fill();

    // Roof (triangle)
    const roofPeak = baseY - hh - H * 0.14;
    ctx.fillStyle = roofColor;
    ctx.beginPath();
    ctx.moveTo(baseX - W * 0.03, baseY - hh);
    ctx.lineTo(baseX + hw * 0.5,  roofPeak);
    ctx.lineTo(baseX + hw + W * 0.03, baseY - hh);
    ctx.closePath();
    ctx.fill();

    // Door
    const doorW = hw * 0.14;
    const doorH = hh * 0.45;
    const doorX = baseX + hw * 0.43;
    const doorY = baseY - doorH;
    ctx.fillStyle = dark ? '#0f2233' : '#a0b8d8';
    ctx.beginPath();
    ctx.roundRect(doorX, doorY, doorW, doorH, [doorW * 0.4, doorW * 0.4, 0, 0]);
    ctx.fill();

    // Windows
    const winColor = dark ? 'rgba(255,220,80,0.25)' : 'rgba(200,230,255,0.7)';
    [[0.2, 0.5], [0.65, 0.5]].forEach(([rx, ry]) => {
      const wx = baseX + hw * rx;
      const wy = baseY - hh * ry - hh * 0.16;
      const ww = hw * 0.13;
      const wh = hh * 0.22;
      ctx.fillStyle = winColor;
      ctx.beginPath();
      ctx.roundRect(wx, wy, ww, wh, 4);
      ctx.fill();

      // Window glow (night)
      if (dark) {
        ctx.fillStyle = `rgba(255,200,50,${0.05 + Math.sin(time * 0.04) * 0.03})`;
        ctx.beginPath();
        ctx.roundRect(wx - 4, wy - 4, ww + 8, wh + 8, 8);
        ctx.fill();
      }

      // Window cross
      ctx.strokeStyle = dark ? 'rgba(255,220,100,0.3)' : 'rgba(150,180,220,0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(wx + ww / 2, wy); ctx.lineTo(wx + ww / 2, wy + wh);
      ctx.moveTo(wx, wy + wh / 2); ctx.lineTo(wx + ww, wy + wh / 2);
      ctx.stroke();
    });

    // Chimney
    ctx.fillStyle = dark ? '#142233' : '#b0c4de';
    ctx.fillRect(baseX + hw * 0.15, roofPeak + H * 0.05, W * 0.035, H * 0.06);
  }

  /** Solar panels on the roof */
  function drawSolarPanels() {
    const dark   = isDark();
    const roofY  = H * 0.38;
    const startX = W * 0.28;
    const panelW = W * 0.055;
    const panelH = H * 0.048;
    const count  = 5;
    const tilt   = 0.18; // radians

    for (let i = 0; i < count; i++) {
      const px = startX + i * (panelW + 4);
      const py = roofY - i * 1.5;

      ctx.save();
      ctx.translate(px + panelW / 2, py + panelH / 2);
      ctx.rotate(-tilt);

      // Panel body
      const panelGrad = ctx.createLinearGradient(-panelW/2, -panelH/2, panelW/2, panelH/2);
      panelGrad.addColorStop(0, dark ? '#0a3a6e' : '#1565C0');
      panelGrad.addColorStop(0.5, dark ? '#0d4f9e' : '#1976D2');
      panelGrad.addColorStop(1, dark ? '#0a3a6e' : '#1565C0');

      ctx.fillStyle = panelGrad;
      ctx.beginPath();
      ctx.roundRect(-panelW/2, -panelH/2, panelW, panelH, 3);
      ctx.fill();

      // Reflection shimmer
      const shimmerAlpha = 0.08 + Math.sin(time * 0.04 + i * 0.8) * 0.06;
      ctx.fillStyle = `rgba(255,255,255,${shimmerAlpha})`;
      ctx.beginPath();
      ctx.moveTo(-panelW/2, -panelH/2);
      ctx.lineTo(0, -panelH/2);
      ctx.lineTo(-panelW*0.2, panelH/2);
      ctx.lineTo(-panelW/2, panelH/2);
      ctx.closePath();
      ctx.fill();

      // Grid lines
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.lineWidth   = 0.8;
      for (let gx = -panelW/2 + panelW/3; gx < panelW/2; gx += panelW/3) {
        ctx.beginPath();
        ctx.moveTo(gx, -panelH/2);
        ctx.lineTo(gx, panelH/2);
        ctx.stroke();
      }
      for (let gy = -panelH/2 + panelH/2; gy < panelH/2; gy += panelH/2) {
        ctx.beginPath();
        ctx.moveTo(-panelW/2, gy);
        ctx.lineTo(panelW/2, gy);
        ctx.stroke();
      }

      // Active glow
      const glowAlpha = 0.15 + Math.sin(time * 0.05 + i * 1.2) * 0.1;
      ctx.strokeStyle = `rgba(77,189,51,${glowAlpha})`;
      ctx.lineWidth   = 1.5;
      ctx.beginPath();
      ctx.roundRect(-panelW/2, -panelH/2, panelW, panelH, 3);
      ctx.stroke();

      ctx.restore();
    }
  }

  /** Power meter / inverter on the house wall */
  function drawInverter() {
    const dark = isDark();
    const ix   = W * 0.48;
    const iy   = H * 0.62;
    const iw   = W * 0.07;
    const ih   = H * 0.06;

    ctx.fillStyle = dark ? '#1a3050' : '#5c7fa8';
    ctx.beginPath();
    ctx.roundRect(ix - iw / 2, iy - ih / 2, iw, ih, 4);
    ctx.fill();

    // Blinking LED
    const ledAlpha = 0.5 + Math.sin(time * 0.08) * 0.5;
    ctx.fillStyle  = `rgba(77,189,51,${ledAlpha})`;
    ctx.beginPath();
    ctx.arc(ix, iy, 3, 0, Math.PI * 2);
    ctx.fill();

    // Label
    ctx.fillStyle = dark ? 'rgba(255,255,255,0.4)' : 'rgba(255,255,255,0.75)';
    ctx.font      = `bold ${W * 0.012}px Poppins, sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText('INV', ix, iy + H * 0.015);
  }

  /** Power grid lines from house to edge */
  function drawGridLines() {
    const dark = isDark();
    const ox   = W * 0.15;
    const oy   = H * 0.55;
    const tx   = W;
    const ty   = H * 0.40;

    // Dashed power line
    ctx.setLineDash([6, 8]);
    ctx.strokeStyle = dark ? 'rgba(77,189,51,0.18)' : 'rgba(4,80,151,0.12)';
    ctx.lineWidth   = 1.5;
    ctx.beginPath();
    ctx.moveTo(ox, oy);
    ctx.bezierCurveTo(ox + (tx - ox) * 0.3, oy, ox + (tx - ox) * 0.6, ty, tx, ty);
    ctx.stroke();
    ctx.setLineDash([]);

    // Power line animation dots
    const dotCount = 4;
    for (let d = 0; d < dotCount; d++) {
      const t2  = ((time * 0.003 + d / dotCount) % 1);
      const bx2 = Math.pow(1-t2,3)*ox + 3*Math.pow(1-t2,2)*t2*(ox+(tx-ox)*0.3)
                + 3*(1-t2)*t2*t2*(ox+(tx-ox)*0.6) + t2*t2*t2*tx;
      const by2 = Math.pow(1-t2,3)*oy + 3*Math.pow(1-t2,2)*t2*oy
                + 3*(1-t2)*t2*t2*ty + t2*t2*t2*ty;
      ctx.beginPath();
      ctx.arc(bx2, by2, 3, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(77,189,51,${0.6 + Math.sin(time*0.1+d)*0.3})`;
      ctx.fill();
    }
  }

  /** Cloud(s) */
  function drawClouds() {
    const dark  = isDark();
    const cycle = (Math.sin(time * 0.003) + 1) / 2;
    if (dark && cycle < 0.3) return;

    const cloudAlpha = dark ? 0.08 : 0.55;
    const cx  = (W * 0.15 + (time * 0.04) % (W * 1.3)) % (W * 1.3) - W * 0.15;
    const cy  = H * 0.18;

    ctx.fillStyle = `rgba(255,255,255,${cloudAlpha})`;
    [[0,0,28], [-22,12,20], [22,10,22], [44,6,18]].forEach(([dx, dy, r]) => {
      ctx.beginPath();
      ctx.arc(cx + dx, cy + dy, r, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  /** kWh readout text on the canvas */
  function drawReadout() {
    const dark  = isDark();
    const kwh   = (3.8 + Math.sin(time * 0.02) * 0.4).toFixed(1);
    const rx    = W * 0.82;
    const ry    = H * 0.7;

    ctx.fillStyle   = dark ? 'rgba(15,32,68,0.85)' : 'rgba(255,255,255,0.88)';
    ctx.shadowColor = 'rgba(0,0,0,0.15)';
    ctx.shadowBlur  = 10;
    ctx.beginPath();
    ctx.roundRect(rx - W * 0.1, ry - H * 0.04, W * 0.2, H * 0.085, 10);
    ctx.fill();
    ctx.shadowBlur = 0;

    ctx.fillStyle   = '#FFD700';
    ctx.font        = `bold ${W * 0.038}px Poppins,sans-serif`;
    ctx.textAlign   = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${kwh} kW`, rx, ry + H * 0.005);

    ctx.fillStyle   = dark ? 'rgba(255,255,255,0.5)' : '#475569';
    ctx.font        = `${W * 0.018}px Inter,sans-serif`;
    ctx.fillText('Live Output', rx, ry + H * 0.035);
  }

  /* ── Main draw loop ── */
  function draw() {
    ctx.clearRect(0, 0, W, H);
    time++;

    drawSky();
    drawStars();
    drawClouds();
    drawSun();
    drawGround();
    drawGridLines();
    drawHouse();
    drawSolarPanels();
    drawInverter();

    // Update & draw particles
    particles.forEach(p => { p.update(); p.draw(); });

    drawReadout();

    raf = requestAnimationFrame(draw);
  }

  /* ── Init ── */
  resize();
  draw();

  // Re-size on window change
  const ro = new ResizeObserver(() => {
    cancelAnimationFrame(raf);
    resize();
    draw();
  });
  ro.observe(canvas);

  // Theme change → next frame will auto-reflect (reads isDark() live)

})();


/* ============================================================
   2. ROI CALCULATOR
   ============================================================ */

(function initROICalculator() {

  const calculateBtn  = document.getElementById('calculate-roi');
  const billInput     = document.getElementById('monthly-bill');
  const areaInput     = document.getElementById('roof-area');
  const stateSelect   = document.getElementById('state-select');
  const billHint      = document.getElementById('monthly-bill-hint');

  // Result elements
  const elSavings  = document.getElementById('result-annual-savings');
  const elSystem   = document.getElementById('result-system-size');
  const elPayback  = document.getElementById('result-payback');
  const elCO2      = document.getElementById('result-co2');
  const elOffset   = document.getElementById('result-offset-pct');
  const progressBar= document.getElementById('roi-progress-bar');
  const progressContainer = document.getElementById('offset-bar-container');

  if (!calculateBtn) return;

  /** Validate input fields */
  function validate() {
    const bill = parseFloat(billInput.value);
    if (!bill || bill < 500) {
      billInput.classList.add('error');
      billHint.textContent = 'Please enter a monthly bill of at least ₹500.';
      billInput.focus();
      return false;
    }
    billInput.classList.remove('error');
    billHint.textContent = '';
    return true;
  }

  /** Animate a number from current displayed value to target */
  function animateValue(el, target, prefix = '', suffix = '', decimals = 0) {
    const start    = 0;
    const duration = 900;
    const startTs  = performance.now();

    function step(ts) {
      const progress = Math.min((ts - startTs) / duration, 1);
      const eased    = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      const current  = start + (target - start) * eased;
      el.textContent = prefix + current.toFixed(decimals) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  /** Core calculation engine */
  function calculate() {
    if (!validate()) return;

    const monthlyBill = parseFloat(billInput.value) || 5000;
    const roofArea    = parseFloat(areaInput.value)  || 600;
    const peakSunHrs  = parseFloat(stateSelect.value) || 5.2;

    // kWh from bill (avg rate ₹7/unit)
    const monthlyKWh = monthlyBill / 7;
    const annualKWh  = monthlyKWh * 12;

    // System size (kW)
    const systemSize = Math.min(
      annualKWh / (peakSunHrs * 365 * 0.80),
      roofArea / 100 // ~100 sq ft per kW
    );
    const roundedSize = Math.max(1, Math.round(systemSize * 10) / 10);

    // Annual solar generation
    const annualGenKWh = roundedSize * peakSunHrs * 365 * 0.80;

    // Grid offset %
    const offsetPct = Math.min(85, Math.round((annualGenKWh / annualKWh) * 100));

    // Annual savings (₹)
    const annualSavings = Math.round(annualKWh * (offsetPct / 100) * 7);

    // System cost (₹55,000/kW average installed)
    const systemCost = roundedSize * 55000;

    // Payback years
    const payback = annualSavings > 0 ? (systemCost / annualSavings).toFixed(1) : '—';

    // CO₂ offset (0.82 kg CO₂ / kWh for Indian grid)
    const co2Tonnes = ((annualGenKWh * 0.82) / 1000).toFixed(1);

    // ── Animate results ──
    animateValue(elSavings,  annualSavings, '₹', '', 0);
    animateValue(elSystem,   roundedSize,   '',  ' kW', 1);
    animateValue(elPayback,  parseFloat(payback), '', ' yrs', 1);
    animateValue(elCO2,      parseFloat(co2Tonnes), '', ' T', 1);
    animateValue(elOffset,   offsetPct, '', '%', 0);

    // Progress bar
    progressBar.style.width = offsetPct + '%';
    progressContainer.setAttribute('aria-valuenow', offsetPct);

    // Toast feedback
    if (window.SolarEchos) {
      window.SolarEchos.showToast(
        `Great news! You could save ₹${annualSavings.toLocaleString('en-IN')} per year with solar.`,
        'success'
      );
    }
  }

  calculateBtn.addEventListener('click', calculate);

  // Allow Enter key on inputs
  [billInput, areaInput, stateSelect].forEach(el => {
    if (!el) return;
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter') calculate();
    });
  });

  // Clear error on input
  billInput.addEventListener('input', () => {
    billInput.classList.remove('error');
    billHint.textContent = '';
  });

})();


/* ============================================================
   3. TESTIMONIALS SLIDER
   ============================================================ */

(function initTestimonialsSlider() {

  const track    = document.getElementById('testimonials-track');
  const dotsWrap = document.getElementById('testimonials-dots');
  const prevBtn  = document.getElementById('prev-testimonial');
  const nextBtn  = document.getElementById('next-testimonial');

  if (!track) return;

  const cards    = Array.from(track.querySelectorAll('.testimonial-card'));
  let currentIdx = 0;
  let autoTimer;

  // Build dot buttons
  cards.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = 'testimonials__dot' + (i === 0 ? ' active' : '');
    dot.setAttribute('aria-label', `Go to testimonial ${i + 1}`);
    dot.setAttribute('role', 'tab');
    dot.setAttribute('aria-selected', String(i === 0));
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
  });

  function goTo(idx) {
    currentIdx = (idx + cards.length) % cards.length;

    // On desktop: scroll track; on mobile: noop (CSS scroll handles it)
    if (window.innerWidth > 768) {
      // Each card is 1fr — calculate offset
      const cardW = track.offsetWidth / cards.length;
      // We only show a portion — actually we use CSS grid on desktop
      // so we fade/highlight the active card instead
      cards.forEach((c, i) => {
        c.style.opacity = i === currentIdx ? '1' : '0.6';
        c.style.transform = i === currentIdx ? 'translateY(-4px) scale(1.02)' : 'scale(1)';
      });
    }

    // Update dots
    dotsWrap.querySelectorAll('.testimonials__dot').forEach((d, i) => {
      d.classList.toggle('active', i === currentIdx);
      d.setAttribute('aria-selected', String(i === currentIdx));
    });
  }

  function next() { goTo(currentIdx + 1); }
  function prev() { goTo(currentIdx - 1); }

  nextBtn?.addEventListener('click', () => { next(); resetAuto(); });
  prevBtn?.addEventListener('click', () => { prev(); resetAuto(); });

  function startAuto() {
    autoTimer = setInterval(next, 4500);
  }

  function resetAuto() {
    clearInterval(autoTimer);
    startAuto();
  }

  // Keyboard
  track.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') { next(); resetAuto(); }
    if (e.key === 'ArrowLeft')  { prev(); resetAuto(); }
  });

  // Pause on hover
  track.addEventListener('mouseenter', () => clearInterval(autoTimer));
  track.addEventListener('mouseleave', startAuto);

  startAuto();
  goTo(0);

})();


/* ============================================================
   4. COUNTER ANIMATION (Impact section)
   Triggers when the impact section scrolls into view.
   ============================================================ */

(function initCounters() {

  function animateCounter(el) {
    const target  = parseFloat(el.getAttribute('data-count-to'));
    const suffix  = el.getAttribute('data-suffix') || '';
    const decimals = target % 1 !== 0 ? 1 : 0;
    const duration = 1800;
    const startTs  = performance.now();

    function step(ts) {
      const progress = Math.min((ts - startTs) / duration, 1);
      const eased    = 1 - Math.pow(1 - progress, 3);
      const value    = target * eased;
      el.textContent = value.toFixed(decimals) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  const counterEls = document.querySelectorAll('.impact__number[data-count-to]');
  if (!counterEls.length) return;

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });

  counterEls.forEach(el => observer.observe(el));

})();


/* ============================================================
   5. LUCIDE ICONS RE-INIT after component injection
   The navbar/footer are loaded asynchronously; icons inside
   them won't be rendered by the inline script. We re-run
   lucide.createIcons() once components are in the DOM.
   ============================================================ */

(function watchForComponentInjection() {

  const observer = new MutationObserver(() => {
    if (window.lucide) {
      window.lucide.createIcons();
    }
  });

  const navbar = document.getElementById('navbar-placeholder');
  const footer = document.getElementById('footer-placeholder');

  if (navbar) observer.observe(navbar, { childList: true });
  if (footer) observer.observe(footer, { childList: true });

})();

/* ============================================================
   END OF HOME-1 JAVASCRIPT
   ============================================================ */
